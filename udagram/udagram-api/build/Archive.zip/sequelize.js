"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_typescript_1 = require("sequelize-typescript");
const config_1 = require("./config/config");
//  export const sequelize = new Sequelize(
//    "postgres://postgres:postgres@database-1.cwqnyw2ecxvp.us-east-1.rds.amazonaws.com:5432/postgres"
//  );
exports.sequelize = new sequelize_typescript_1.Sequelize({
    username: config_1.config.username,
    password: config_1.config.password,
    database: config_1.config.database,
    host: config_1.config.host,
    port: config_1.config.dbport,
    dialect: "postgres",
    storage: ":memory:",
});
//# sourceMappingURL=sequelize.js.map